"""AI plant identification / problem spotting.

Two layers:
1. A vision-LLM call (Anthropic API) when ANTHROPIC_API_KEY is set — identifies the plant,
   possible problems and care advice, in the user's language.
2. An offline fallback using simple colour analysis (Pillow) that estimates how much of the
   visible leaf area looks yellow/brown (a rough sign of stress). It cannot name the plant.
"""
import base64
import io
import json
import os

import requests
from PIL import Image

LANG_NAMES = {"en": "English", "ta": "Tamil", "hi": "Hindi"}
MODEL = os.environ.get("GENZFARMER_MODEL", "claude-sonnet-5-5")


def _decode(b64):
    if "," in b64[:100]:
        b64 = b64.split(",", 1)[1]
    raw = base64.b64decode(b64)
    img = Image.open(io.BytesIO(raw))
    img.load()
    return raw, img


def colour_analysis(img):
    img = img.convert("RGB")
    img.thumbnail((200, 200))
    px = list(img.getdata())
    green = stress = 0
    for r, g, b in px:
        if g > r * 1.05 and g > b * 1.1:
            green += 1
        elif r > 120 and g > 80 and b < min(r, g) * 0.7:  # yellow / brown tones
            stress += 1
    plant = green + stress
    return {
        "green_pct": round(100 * green / len(px), 1),
        "stress_pct": round(100 * stress / plant, 1) if plant else None,
    }


def _llm(raw, img, lang):
    key = os.environ["ANTHROPIC_API_KEY"]
    fmt = (img.format or "JPEG").lower()
    media = {"jpg": "jpeg"}.get(fmt, fmt)
    prompt = (
        "You are an agricultural assistant. Look at this plant photo. Reply ONLY with JSON: "
        '{"plant": str, "confidence": "low|medium|high", "possible_issues": [str], "advice": [str]}. '
        f"Write all text values in {LANG_NAMES.get(lang, 'English')}. If it is not a plant, say so in 'plant'. "
        "Be honest about uncertainty; do not invent a diagnosis you cannot see."
    )
    r = requests.post(
        "https://api.anthropic.com/v1/messages",
        headers={"x-api-key": key, "anthropic-version": "2023-06-01", "content-type": "application/json"},
        json={"model": MODEL, "max_tokens": 600, "messages": [{"role": "user", "content": [
            {"type": "image", "source": {"type": "base64", "media_type": f"image/{media}",
                                         "data": base64.b64encode(raw).decode()}},
            {"type": "text", "text": prompt}]}]},
        timeout=60,
    )
    r.raise_for_status()
    text = r.json()["content"][0]["text"]
    return json.loads(text[text.index("{"): text.rindex("}") + 1])


def identify(image_b64, lang="en"):
    raw, img = _decode(image_b64)
    result = {"mode": "offline", "colour": colour_analysis(img)}
    if os.environ.get("ANTHROPIC_API_KEY"):
        try:
            result.update(_llm(raw, img, lang))
            result["mode"] = "ai"
        except Exception as e:  # keep the app usable if the API is unreachable
            result["note"] = f"AI service unavailable ({type(e).__name__}); showing basic colour analysis only."
    else:
        result["note"] = "Set ANTHROPIC_API_KEY to enable AI plant identification. Showing basic colour analysis only."
    return result
