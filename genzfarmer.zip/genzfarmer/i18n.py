"""English / Tamil / Hindi strings for GENZFARMER (UI + advisory text)."""

LANGS = {"en": "English", "ta": "தமிழ்", "hi": "हिन्दी"}

CROP_NAMES = {
    "tomato": {"en": "Tomato", "ta": "தக்காளி", "hi": "टमाटर"},
    "rice": {"en": "Rice", "ta": "நெல்", "hi": "धान"},
    "wheat": {"en": "Wheat", "ta": "கோதுமை", "hi": "गेहूं"},
    "maize": {"en": "Maize", "ta": "மக்காச்சோளம்", "hi": "मक्का"},
    "cotton": {"en": "Cotton", "ta": "பருத்தி", "hi": "कपास"},
    "sugarcane": {"en": "Sugarcane", "ta": "கரும்பு", "hi": "गन्ना"},
    "groundnut": {"en": "Groundnut", "ta": "நிலக்கடலை", "hi": "मूंगफली"},
    "banana": {"en": "Banana", "ta": "வாழை", "hi": "केला"},
    "chilli": {"en": "Chilli", "ta": "மிளகாய்", "hi": "मिर्च"},
    "onion": {"en": "Onion", "ta": "வெங்காயம்", "hi": "प्याज"},
    "potato": {"en": "Potato", "ta": "உருளைக்கிழங்கு", "hi": "आलू"},
    "brinjal": {"en": "Brinjal", "ta": "கத்திரிக்காய்", "hi": "बैंगन"},
    "turmeric": {"en": "Turmeric", "ta": "மஞ்சள்", "hi": "हल्दी"},
}

SEASONS = {
    "summer": {"en": "Summer", "ta": "கோடை", "hi": "गर्मी"},
    "monsoon": {"en": "Monsoon", "ta": "பருவமழை", "hi": "मानसून"},
    "winter": {"en": "Winter", "ta": "குளிர்காலம்", "hi": "सर्दी"},
}

SOILS = {
    "loamy": {"en": "Loamy", "ta": "இருமண்பாட்டு மண்", "hi": "दोमट"},
    "sandy": {"en": "Sandy", "ta": "மணல் மண்", "hi": "रेतीली"},
    "clay": {"en": "Clay", "ta": "களிமண்", "hi": "चिकनी"},
    "black": {"en": "Black", "ta": "கரிசல் மண்", "hi": "काली"},
    "red": {"en": "Red", "ta": "செம்மண்", "hi": "लाल"},
    "alluvial": {"en": "Alluvial", "ta": "வண்டல் மண்", "hi": "जलोढ़"},
}

STAGES = {
    "germination": {"en": "Germination", "ta": "முளைப்பு", "hi": "अंकुरण"},
    "vegetative": {"en": "Vegetative", "ta": "வளர்ச்சி நிலை", "hi": "वानस्पतिक वृद्धि"},
    "flowering": {"en": "Flowering", "ta": "பூக்கும் நிலை", "hi": "फूल आना"},
    "fruiting": {"en": "Fruiting", "ta": "காய்ப்பு நிலை", "hi": "फल बनना"},
    "harvest": {"en": "Harvest", "ta": "அறுவடை", "hi": "कटाई"},
}

STAGE_TIPS = {
    "germination": {
        "en": "Keep soil moist but not waterlogged; protect seedlings from harsh sun and pests.",
        "ta": "மண்ணை ஈரமாக வைத்திருங்கள், நீர் தேங்க விடாதீர்கள்; இளம் நாற்றுகளை கடும் வெயில், பூச்சிகளிலிருந்து பாதுகாக்கவும்.",
        "hi": "मिट्टी को नम रखें, जलभराव न होने दें; पौधों को तेज धूप और कीटों से बचाएं।",
    },
    "vegetative": {
        "en": "Apply nitrogen in split doses, weed regularly and monitor for leaf pests.",
        "ta": "நைட்ரஜன் உரத்தை பிரித்து இடவும், களைகளை அடிக்கடி அகற்றவும், இலைப் பூச்சிகளை கண்காணிக்கவும்.",
        "hi": "नाइट्रोजन को बाँटकर दें, नियमित निराई करें और पत्तों के कीटों पर नज़र रखें।",
    },
    "flowering": {
        "en": "Avoid water stress now; ensure phosphorus and potassium; avoid spraying at peak flowering hours.",
        "ta": "இப்போது நீர்ப் பற்றாக்குறை வராமல் பார்த்துக்கொள்ளுங்கள்; பாஸ்பரஸ், பொட்டாஷ் உரம் உறுதிசெய்யுங்கள்; பூக்கும் நேரத்தில் மருந்து தெளிப்பதைத் தவிர்க்கவும்.",
        "hi": "इस समय पानी की कमी न होने दें; फॉस्फोरस और पोटाश दें; फूल आने के समय छिड़काव से बचें।",
    },
    "fruiting": {
        "en": "Maintain steady irrigation, support heavy plants and watch for fruit borers and fungal disease.",
        "ta": "சீரான நீர்ப்பாசனம் தொடருங்கள், கனமான செடிகளுக்கு முட்டு கொடுங்கள், காய்த்துளைப்பான் மற்றும் பூஞ்சை நோய்களை கவனியுங்கள்.",
        "hi": "लगातार सिंचाई रखें, भारी पौधों को सहारा दें और फल छेदक व फफूंद रोगों पर नज़र रखें।",
    },
    "harvest": {
        "en": "Reduce irrigation, harvest at the right maturity and store in a cool, dry place.",
        "ta": "நீர்ப்பாசனத்தைக் குறையுங்கள், சரியான முதிர்ச்சியில் அறுவடை செய்து குளிர்ச்சியான வறண்ட இடத்தில் சேமிக்கவும்.",
        "hi": "सिंचाई कम करें, सही परिपक्वता पर कटाई करें और ठंडी, सूखी जगह पर भंडारण करें।",
    },
}

UNITS = {
    "kg": {"en": "kg", "ta": "கிலோ", "hi": "किग्रा"},
    "g": {"en": "g", "ta": "கிராம்", "hi": "ग्राम"},
    "t": {"en": "tonnes", "ta": "டன்", "hi": "टन"},
    "plants": {"en": "plants", "ta": "செடிகள்", "hi": "पौधे"},
    "L": {"en": "litres", "ta": "லிட்டர்", "hi": "लीटर"},
    "days": {"en": "days", "ta": "நாட்கள்", "hi": "दिन"},
}

MSG = {
    "season_ok": {
        "en": "{crop} suits the {season} season.",
        "ta": "{crop} பயிர் {season} பருவத்திற்கு ஏற்றது.",
        "hi": "{crop} {season} मौसम के लिए उपयुक्त है।",
    },
    "season_bad": {
        "en": "{crop} is not ideal for {season}. Best seasons: {best}.",
        "ta": "{crop} பயிர் {season} பருவத்திற்கு ஏற்றதல்ல. சிறந்த பருவங்கள்: {best}.",
        "hi": "{crop} {season} मौसम के लिए आदर्श नहीं है। सर्वोत्तम मौसम: {best}।",
    },
    "soil_ok": {
        "en": "{soil} soil works well for {crop}.",
        "ta": "{soil} {crop} பயிருக்கு ஏற்றது.",
        "hi": "{soil} मिट्टी {crop} के लिए उपयुक्त है।",
    },
    "soil_bad": {
        "en": "{soil} soil is not ideal for {crop}. Better soils: {best}. Add organic matter to improve it.",
        "ta": "{soil} {crop} பயிருக்கு ஏற்றதல்ல. சிறந்த மண் வகைகள்: {best}. கரிம எருவைச் சேர்த்து மண்ணை மேம்படுத்தவும்.",
        "hi": "{soil} मिट्टी {crop} के लिए आदर्श नहीं है। बेहतर मिट्टी: {best}। जैविक खाद डालकर सुधार करें।",
    },
    "ph_ok": {
        "en": "Soil pH {ph} is within the ideal range ({lo}–{hi}).",
        "ta": "மண் அமில காரநிலை (pH) {ph} சிறந்த அளவிற்குள் ({lo}–{hi}) உள்ளது.",
        "hi": "मिट्टी का pH {ph} आदर्श सीमा ({lo}–{hi}) के भीतर है।",
    },
    "ph_low": {
        "en": "Soil pH {ph} is too acidic (ideal {lo}–{hi}). Apply agricultural lime.",
        "ta": "மண் pH {ph} அமிலத்தன்மை அதிகம் (சிறந்தது {lo}–{hi}). சுண்ணாம்பு இடவும்.",
        "hi": "मिट्टी का pH {ph} अधिक अम्लीय है (आदर्श {lo}–{hi})। चूना डालें।",
    },
    "ph_high": {
        "en": "Soil pH {ph} is too alkaline (ideal {lo}–{hi}). Apply gypsum or organic compost.",
        "ta": "மண் pH {ph} காரத்தன்மை அதிகம் (சிறந்தது {lo}–{hi}). ஜிப்சம் அல்லது கரிம உரம் இடவும்.",
        "hi": "मिट्टी का pH {ph} अधिक क्षारीय है (आदर्श {lo}–{hi})। जिप्सम या जैविक खाद डालें।",
    },
}

UI = {
    "title": {"en": "GENZFARMER AI", "ta": "ஜென்Z ஃபார்மர் AI", "hi": "जेनज़ी फार्मर AI"},
    "subtitle": {
        "en": "AI-Powered Smart Farming & Crop Advisory",
        "ta": "AI அடிப்படையிலான ஸ்மார்ட் விவசாய ஆலோசனை",
        "hi": "AI आधारित स्मार्ट खेती और फसल सलाह",
    },
    "crop": {"en": "Crop name", "ta": "பயிர் பெயர்", "hi": "फसल का नाम"},
    "land": {"en": "Land size (acres)", "ta": "நில அளவு (ஏக்கர்)", "hi": "भूमि का आकार (एकड़)"},
    "season": {"en": "Season", "ta": "பருவம்", "hi": "मौसम"},
    "soil": {"en": "Soil type", "ta": "மண் வகை", "hi": "मिट्टी का प्रकार"},
    "ph": {"en": "Soil pH", "ta": "மண் pH", "hi": "मिट्टी का pH"},
    "stage": {"en": "Growth stage", "ta": "வளர்ச்சி நிலை", "hi": "वृद्धि अवस्था"},
    "image": {"en": "Plant photo (optional)", "ta": "செடி புகைப்படம் (விருப்பம்)", "hi": "पौधे की फोटो (वैकल्पिक)"},
    "submit": {"en": "Get advisory", "ta": "ஆலோசனை பெறு", "hi": "सलाह लें"},
    "loading": {"en": "Analysing…", "ta": "ஆய்வு செய்கிறது…", "hi": "विश्लेषण हो रहा है…"},
    "suitability": {"en": "Suitability", "ta": "பொருத்தம்", "hi": "उपयुक्तता"},
    "advice": {"en": "Advisory", "ta": "ஆலோசனை", "hi": "सलाह"},
    "resources": {"en": "Resource plan", "ta": "வள திட்டம்", "hi": "संसाधन योजना"},
    "water_total": {"en": "Total water for the crop cycle", "ta": "பயிர் காலம் முழுவதும் தேவையான நீர்", "hi": "फसल चक्र के लिए कुल पानी"},
    "water_daily": {"en": "Average water per day", "ta": "நாளொன்றுக்கு சராசரி நீர்", "hi": "प्रति दिन औसत पानी"},
    "fertilizer": {"en": "Fertilizer (N : P : K)", "ta": "உரம் (N : P : K)", "hi": "उर्वरक (N : P : K)"},
    "seed": {"en": "Seed / planting material", "ta": "விதை / நடவுப் பொருள்", "hi": "बीज / रोपण सामग्री"},
    "duration": {"en": "Crop duration", "ta": "பயிர் காலம்", "hi": "फसल अवधि"},
    "alternatives": {"en": "Better-suited crops for your conditions", "ta": "உங்கள் நிலைக்கு ஏற்ற பிற பயிர்கள்", "hi": "आपकी स्थिति के लिए बेहतर फसलें"},
    "plant_id": {"en": "Plant image analysis", "ta": "செடி பட ஆய்வு", "hi": "पौधे की छवि का विश्लेषण"},
    "disclaimer": {
        "en": "Values are approximate guidance. Confirm with your local agriculture officer before large decisions.",
        "ta": "மதிப்புகள் தோராய வழிகாட்டுதலே. பெரிய முடிவுகளுக்கு முன் உங்கள் வேளாண் அலுவலரிடம் உறுதிசெய்யுங்கள்.",
        "hi": "मान लगभग मार्गदर्शन हैं। बड़े निर्णय से पहले अपने कृषि अधिकारी से पुष्टि करें।",
    },
    "level_ok": {"en": "Good", "ta": "சரி", "hi": "सही"},
    "level_warn": {"en": "Attention", "ta": "கவனம்", "hi": "ध्यान दें"},
    "level_info": {"en": "Tip", "ta": "குறிப்பு", "hi": "सुझाव"},
    "error": {"en": "Something went wrong. Please try again.", "ta": "ஏதோ பிழை ஏற்பட்டது. மீண்டும் முயற்சிக்கவும்.", "hi": "कुछ गलत हुआ। कृपया फिर प्रयास करें।"},
}


def pick(table, key, lang):
    entry = table.get(key, {})
    return entry.get(lang) or entry.get("en") or key


def msg(key, lang, **kw):
    tmpl = MSG[key].get(lang) or MSG[key]["en"]
    return tmpl.format(**kw)


def ui_bundle(lang):
    """Everything the front-end needs for one language."""
    return {
        "ui": {k: v.get(lang, v["en"]) for k, v in UI.items()},
        "crops": {k: v.get(lang, v["en"]) for k, v in CROP_NAMES.items()},
        "seasons": {k: v.get(lang, v["en"]) for k, v in SEASONS.items()},
        "soils": {k: v.get(lang, v["en"]) for k, v in SOILS.items()},
        "stages": {k: v.get(lang, v["en"]) for k, v in STAGES.items()},
    }
