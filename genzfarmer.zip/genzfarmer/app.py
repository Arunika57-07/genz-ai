"""GENZFARMER AI – Flask backend.

/api/analyze  : single entry point used by the UI. If N8N_WEBHOOK_URL is set the request is
                forwarded to the n8n workflow (which calls /api/advise and /api/identify);
                otherwise it runs the same logic locally.
"""
import os

import requests
from flask import Flask, jsonify, request, send_from_directory

from advisory import CROPS, advise
from i18n import LANGS, ui_bundle
from identify import identify

app = Flask(__name__, static_folder="static", static_url_path="/static")
app.config["MAX_CONTENT_LENGTH"] = 12 * 1024 * 1024


@app.get("/")
def index():
    return send_from_directory("static", "index.html")


@app.get("/api/i18n/<lang>")
def i18n(lang):
    return jsonify({"langs": LANGS, **ui_bundle(lang if lang in LANGS else "en")})


@app.get("/api/crops")
def crops():
    return jsonify(sorted(CROPS))


@app.post("/api/advise")
def api_advise():
    d = request.get_json(force=True, silent=True) or {}
    try:
        return jsonify(advise(d.get("crop"), d.get("acres"), d.get("season"), d.get("soil"),
                              d.get("ph"), d.get("stage"), d.get("lang", "en")))
    except (ValueError, TypeError) as e:
        return jsonify({"error": str(e)}), 400


@app.post("/api/identify")
def api_identify():
    d = request.get_json(force=True, silent=True) or {}
    if not d.get("image_base64"):
        return jsonify({"error": "image_base64 required"}), 400
    try:
        return jsonify(identify(d["image_base64"], d.get("lang", "en")))
    except Exception as e:
        return jsonify({"error": f"Could not read image: {e}"}), 400


@app.post("/api/analyze")
def analyze():
    d = request.get_json(force=True, silent=True) or {}
    n8n = os.environ.get("N8N_WEBHOOK_URL")
    if n8n:
        try:
            r = requests.post(n8n, json=d, timeout=90)
            return (r.text, r.status_code, {"Content-Type": "application/json"})
        except requests.RequestException as e:
            return jsonify({"error": f"n8n workflow unreachable: {e}"}), 502
    try:
        out = {"advisory": advise(d.get("crop"), d.get("acres"), d.get("season"), d.get("soil"),
                                  d.get("ph"), d.get("stage"), d.get("lang", "en"))}
    except (ValueError, TypeError) as e:
        return jsonify({"error": str(e)}), 400
    if d.get("image_base64"):
        try:
            out["identification"] = identify(d["image_base64"], d.get("lang", "en"))
        except Exception as e:
            out["identification"] = {"mode": "error", "note": f"Could not read image: {e}"}
    return jsonify(out)


if __name__ == "__main__":
    app.run(host="0.0.0.0", port=int(os.environ.get("PORT", 5000)), debug=False)
