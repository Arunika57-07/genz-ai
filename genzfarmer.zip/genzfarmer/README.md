# GENZFARMER AI – Smart Farming & Crop Advisory System

Working prototype of the system described in the project presentation
(Arunika M, B.Tech IT, 2023–2027).

## What it does (mapped to the slides)

| Slide module | Where it lives |
|---|---|
| User Interface (crop, land size, season, soil/pH, growth stage, plant image) | `static/index.html` |
| Agricultural Database (water, soil, growth stage) | `data/crops.json` (13 crops) |
| Smart Crop Advisory | `advisory.py` – scores season / soil / pH fit, resource plan scaled to land size, suggests better-suited crops |
| AI Identification (computer vision) | `identify.py` – vision-LLM when `ANTHROPIC_API_KEY` is set, otherwise a basic colour-based leaf-stress estimate |
| Multilingual Assistant | `i18n.py` – English, Tamil, Hindi (UI + advice text) |
| n8n Workflow | `n8n/genzfarmer_workflow.json` |

Workflow: Data Entry → Image Upload → AI Analysis → DB Retrieval → Advisory Generation → Translation → Result Display.

## Run it

```bash
pip install -r requirements.txt
python app.py            # http://localhost:5000
```

Optional:
```bash
export ANTHROPIC_API_KEY=sk-ant-...      # enables AI plant identification
export GENZFARMER_MODEL=claude-sonnet-5-5 # model override (default shown)
```

## Using n8n

1. In n8n: *Import from file* → `n8n/genzfarmer_workflow.json`, then **activate** it.
2. If n8n runs on another host, set `GENZFARMER_API` in n8n's environment to this app's URL
   (default `http://localhost:5000`).
3. Start the app with the production webhook URL:
   ```bash
   export N8N_WEBHOOK_URL=http://localhost:5678/webhook/genzfarmer
   python app.py
   ```
   The UI then sends every request to n8n, which calls `/api/advise` and (if a photo is attached) `/api/identify`.
   Without `N8N_WEBHOOK_URL` the app runs the same logic locally.

## API

- `POST /api/advise`  `{crop, acres, season, soil, ph, stage, lang}`
- `POST /api/identify` `{image_base64, lang}`
- `POST /api/analyze` – combined (used by the UI)
- `GET /api/i18n/<lang>`, `GET /api/crops`

## Known limitations (be upfront about these in your viva)

- `data/crops.json` holds approximate reference values compiled for demonstration, **not** the Kaggle
  dataset itself. To use Kaggle's *Crop Recommendation* data or PlantVillage, download them and
  extend `advisory.py` (e.g. derive pH/temperature ranges per crop from the CSV).
- Without an API key, image analysis only estimates yellow/brown leaf area; it cannot name the plant or disease.
- Tamil/Hindi text is pre-written templates, not live machine translation; have a native speaker review it.
- No IoT/sensor input yet (listed as future scope in the slides: ESP32, weather API, yield prediction).
- The n8n workflow was written to the n8n node schema but should be imported and tested on your n8n version.
