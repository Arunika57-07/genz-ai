"""Smart Crop Advisory engine: rule-based scoring over a crop knowledge base."""
import json
from pathlib import Path

from i18n import CROP_NAMES, SEASONS, SOILS, STAGE_TIPS, STAGES, UNITS, msg, pick

CROPS = {
    k: v for k, v in json.loads((Path(__file__).parent / "data" / "crops.json").read_text(encoding="utf-8")).items()
    if not k.startswith("_")
}
ACRE_MM_TO_LITRES = 4046.86  # 1 mm of water over 1 acre


def _score(crop, season, soil, ph):
    c = CROPS[crop]
    score = 0
    score += 40 if season in c["seasons"] else 0
    score += 30 if (not soil or soil in c["soils"]) else 0
    if ph is None:
        score += 30
    else:
        lo, hi = c["ph"]
        gap = max(lo - ph, ph - hi, 0)
        score += max(0, round(30 - gap * 20))
    return score


def advise(crop, acres, season, soil, ph, stage, lang="en"):
    crop = (crop or "").strip().lower()
    if crop not in CROPS:
        raise ValueError(f"Unsupported crop '{crop}'. Supported: {', '.join(sorted(CROPS))}")
    lang = lang if lang in ("en", "ta", "hi") else "en"
    c = CROPS[crop]
    acres = float(acres or 1)
    if acres <= 0:
        raise ValueError("acres must be > 0")
    ph = float(ph) if ph not in (None, "") else None

    cname = pick(CROP_NAMES, crop, lang)
    items = []

    if season:
        sname = pick(SEASONS, season, lang)
        if season in c["seasons"]:
            items.append({"level": "ok", "text": msg("season_ok", lang, crop=cname, season=sname)})
        else:
            best = ", ".join(pick(SEASONS, s, lang) for s in c["seasons"])
            items.append({"level": "warn", "text": msg("season_bad", lang, crop=cname, season=sname, best=best)})

    if soil:
        soname = pick(SOILS, soil, lang)
        if soil in c["soils"]:
            items.append({"level": "ok", "text": msg("soil_ok", lang, crop=cname, soil=soname)})
        else:
            best = ", ".join(pick(SOILS, s, lang) for s in c["soils"])
            items.append({"level": "warn", "text": msg("soil_bad", lang, crop=cname, soil=soname, best=best)})

    if ph is not None:
        lo, hi = c["ph"]
        key = "ph_ok" if lo <= ph <= hi else ("ph_low" if ph < lo else "ph_high")
        items.append({"level": "ok" if key == "ph_ok" else "warn",
                      "text": msg(key, lang, ph=ph, lo=lo, hi=hi)})

    if stage in STAGE_TIPS:
        items.append({"level": "info",
                      "text": f"{pick(STAGES, stage, lang)}: {STAGE_TIPS[stage].get(lang, STAGE_TIPS[stage]['en'])}"})

    total_l = round(c["water_mm"] * ACRE_MM_TO_LITRES * acres)
    n, p, k = c["npk_kg_acre"]
    seed_qty, seed_unit = c["seed"]
    u = lambda code: pick(UNITS, code, lang)

    alternatives = []
    own = _score(crop, season, soil, ph)
    if season or soil or ph is not None:
        ranked = sorted((x for x in CROPS if x != crop and _score(x, season, soil, ph) > own),
                        key=lambda x: -_score(x, season, soil, ph))
        alternatives = [{"crop": x, "name": pick(CROP_NAMES, x, lang), "score": _score(x, season, soil, ph)}
                        for x in ranked[:3]]

    return {
        "crop": crop,
        "crop_name": cname,
        "suitability": _score(crop, season, soil, ph),
        "advice": items,
        "resources": {
            "water_total": f"{total_l:,} {u('L')}",
            "water_daily": f"{round(total_l / c['duration_days']):,} {u('L')}",
            "fertilizer": f"{round(n * acres)} : {round(p * acres)} : {round(k * acres)} {u('kg')}",
            "seed": f"{round(seed_qty * acres):,} {u(seed_unit)}",
            "duration": f"{c['duration_days']} {u('days')}",
        },
        "alternatives": alternatives,
    }
